/**
  ******************************************************************************
  * file           : main.c
  * brief          : Main program body
  *                  Calls target system initialization then loop in main.
  ******************************************************************************
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "stm32c5xx_hal_uart.h"

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private functions prototype -----------------------------------------------*/
uint8_t rx_buffer[100];
void HAL_UART_RxCpltCallback(hal_uart_handle_t *huart, uint32_t size_byte, hal_uart_rx_event_types_t rx_event)
{
  if (huart->instance == HAL_UART1)
  { 
    HAL_UART_ReceiveToIdle_DMA(mx_usart1_uart_init(), (uint8_t *)rx_buffer, sizeof(rx_buffer));
      HAL_UART_Transmit_DMA(mx_usart1_uart_init(), (uint8_t *)rx_buffer, sizeof(rx_buffer));
      if(rx_buffer[0] == 0x01) {
        HAL_GPIO_WritePin(HAL_GPIOC, HAL_GPIO_PIN_0, HAL_GPIO_PIN_RESET);
      } else if(rx_buffer[0] == 0x00) {
        HAL_GPIO_WritePin(HAL_GPIOC, HAL_GPIO_PIN_0, HAL_GPIO_PIN_SET);
      }

    HAL_UART_ReceiveToIdle_DMA(huart, (uint8_t *)rx_buffer, sizeof(rx_buffer));
  }
}
/**
  * brief:  The application entry point.
  * retval: none but we specify int to comply with C99 standard
  */
int main(void)
{
  /** System Init: this code placed in targets folder initializes your system.
    * It calls the initialization (and sets the initial configuration) of the peripherals.
    * You can use STM32CubeMX to generate and call this code or not in this project.
    * It also contains the HAL initialization and the initial clock configuration.
    */
  if (mx_system_init() != SYSTEM_OK)
  {
    return (-1);
  }
  else
  {
    HAL_UART_ReceiveToIdle_DMA(mx_usart1_uart_init(), (uint8_t *)rx_buffer, sizeof(rx_buffer));
    HAL_GPIO_WritePin(HAL_GPIOC, HAL_GPIO_PIN_0, HAL_GPIO_PIN_RESET);  
    while (1) {
     
    }
  }
} /* end main */

