/**
  ******************************************************************************
  * @file           : mx_tim3.c
  * @brief          : Peripheral initialization
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the mx_stm32c5xx_hal_drivers_license.md file
  * in the same directory as the generated code.
  * If no mx_stm32c5xx_hal_drivers_license.md file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "mx_tim3.h"
#include "stm32c5xx_hal_gpio.h"

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private functions prototype------------------------------------------------*/
/* Exported variables by reference--------------------------------------------*/
static hal_tim_handle_t hTIM3;

/* Exported function definition ----------------------------------------------*/
/******************************************************************************/
/* Exported functions for TIM3 in HAL layer */
/******************************************************************************/
hal_tim_handle_t *mx_tim3_init(void)
{
  if (HAL_TIM_Init(&hTIM3, HAL_TIM3) != HAL_OK)
  {
    return NULL;
  }

  HAL_RCC_TIM3_EnableClock();

  /* Timer configuration to reach the output frequency at 1 Hz */
  hal_tim_config_t config;
  config.prescaler              = 7199;
  config.counter_mode           = HAL_TIM_COUNTER_UP;
  config.period                 = 0x270F;
  config.repetition_counter     = 0;
  config.clock_sel.clock_source = HAL_TIM_CLK_INTERNAL;
  if (HAL_TIM_SetConfig(&hTIM3, &config) != HAL_OK)
  {
    return NULL;
  }

  /* Sampling Clock */
  if (HAL_TIM_SetDTSPrescaler(&hTIM3, HAL_TIM_DTS_DIV1) != HAL_OK)
  {
    return NULL;
  }
  if (HAL_TIM_SetDTS2Prescaler(&hTIM3, HAL_TIM_DTS2_DIV1) != HAL_OK)
  {
    return NULL;
  }

  /* Update Event Management */
  if (HAL_TIM_SetUpdateSource(&hTIM3, HAL_TIM_UPDATE_REGULAR) != HAL_OK)
  {
    return NULL;
  }
  if (HAL_TIM_EnableUpdateGeneration(&hTIM3) != HAL_OK)
  {
    return NULL;
  }
  if (HAL_TIM_EnableUpdateFlagRemap(&hTIM3) != HAL_OK)
  {
    return NULL;
  }
  /* Master Mode Configuration */
  /* No GPIO configuration required for TIM3 */
  /* Enable the Timer global interrupt */
  HAL_CORTEX_NVIC_SetPriority(TIM3_IRQn, HAL_CORTEX_NVIC_PREEMP_PRIORITY_0, HAL_CORTEX_NVIC_SUB_PRIORITY_0);
  HAL_CORTEX_NVIC_EnableIRQ(TIM3_IRQn);

  return &hTIM3;
}

void mx_tim3_deinit(void)
{
  (void)HAL_TIM_DeInit(&hTIM3);

  HAL_RCC_TIM3_DisableClock();

  HAL_RCC_TIM3_Reset();

  /* No GPIO de-initialization required for TIM3 */
  /* Disable Timer global interrupt */
  HAL_CORTEX_NVIC_DisableIRQ(TIM3_IRQn);
}

hal_tim_handle_t *mx_tim3_gethandle(void)
{
  return &hTIM3;
}

/******************************************************************************/
/*                           TIM3 global interrupt                            */
/******************************************************************************/
void TIM3_IRQHandler(void)
{
  HAL_GPIO_TogglePin(HAL_GPIOC, HAL_GPIO_PIN_0);
  HAL_TIM_IRQHandler(&hTIM3);
}
