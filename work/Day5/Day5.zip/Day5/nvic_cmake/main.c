/**
  ******************************************************************************
  * file           : main.c
  * brief          : Main program body
  *                  Calls target system initialization then loop in main.
  ******************************************************************************
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

#define IRQ_ID_A                          (1U)
#define IRQ_ID_B                          (2U)
#define IRQ_ID_C                          (3U)
#define IRQ_COUNT                         (3U)

/* Watch these two variables in the debugger. */
volatile uint8_t g_irq_order[IRQ_COUNT] = {0xFFU, 0xFFU, 0xFFU};
volatile uint8_t g_irq_count = 0U;

static void record_irq(uint8_t irq_id)
{
  if (g_irq_count < IRQ_COUNT)
  {
    g_irq_order[g_irq_count] = irq_id;
    g_irq_count++;
  }
}

/* A: preemption 1, subpriority 0 */
void EXTI0_IRQHandler(void)
{
  record_irq(IRQ_ID_A);
  HAL_CORTEX_NVIC_ClearPendingIRQ(EXTI0_IRQn);
}

/* B: preemption 1, subpriority 1 */
void EXTI1_IRQHandler(void)
{
  record_irq(IRQ_ID_B);
  HAL_CORTEX_NVIC_ClearPendingIRQ(EXTI1_IRQn);
}

/* C: preemption 2, subpriority 0 */
void EXTI2_IRQHandler(void)
{
  record_irq(IRQ_ID_C);
  HAL_CORTEX_NVIC_ClearPendingIRQ(EXTI2_IRQn);
}

int main(void)
{
  if (mx_system_init() != SYSTEM_OK)
  {
    return (-1);
  }

  hal_gpio_config_t led_config;

  HAL_RCC_GPIOC_EnableClock();

  led_config.mode = HAL_GPIO_MODE_OUTPUT;
  led_config.speed = HAL_GPIO_SPEED_FREQ_LOW;
  led_config.pull = HAL_GPIO_PULL_NO;
  led_config.output_type = HAL_GPIO_OUTPUT_PUSHPULL;
  led_config.init_state = HAL_GPIO_PIN_SET;

  if (HAL_GPIO_Init(HAL_GPIOC, HAL_GPIO_PIN_0, &led_config) != HAL_OK)
  {
    return (-2);
  }

  __disable_irq();

  /*
   * CubeMX2 currently generates GROUP_4 in mx_cortex_nvic.c.
   * Override it here before configuring the three interrupt priorities.
   */
  HAL_CORTEX_NVIC_SetPriorityGrouping(HAL_CORTEX_NVIC_PRIORITY_GROUP_2);

  HAL_CORTEX_NVIC_SetPriority(EXTI0_IRQn,
                              HAL_CORTEX_NVIC_PREEMP_PRIORITY_1,
                              HAL_CORTEX_NVIC_SUB_PRIORITY_0);
  HAL_CORTEX_NVIC_SetPriority(EXTI1_IRQn,
                              HAL_CORTEX_NVIC_PREEMP_PRIORITY_1,
                              HAL_CORTEX_NVIC_SUB_PRIORITY_1);
  HAL_CORTEX_NVIC_SetPriority(EXTI2_IRQn,
                              HAL_CORTEX_NVIC_PREEMP_PRIORITY_2,
                              HAL_CORTEX_NVIC_SUB_PRIORITY_0);

  HAL_CORTEX_NVIC_EnableIRQ(EXTI0_IRQn);
  HAL_CORTEX_NVIC_EnableIRQ(EXTI1_IRQn);
  HAL_CORTEX_NVIC_EnableIRQ(EXTI2_IRQn);

  /*
   * Keep all three interrupts pending, then enable the CPU interrupt.
   * The CPU must select A first, B second and C last by priority.
   */
  HAL_CORTEX_NVIC_ClearPendingIRQ(EXTI0_IRQn);
  HAL_CORTEX_NVIC_ClearPendingIRQ(EXTI1_IRQn);
  HAL_CORTEX_NVIC_ClearPendingIRQ(EXTI2_IRQn);

  HAL_CORTEX_NVIC_SetPendingIRQ(EXTI2_IRQn);
  HAL_CORTEX_NVIC_SetPendingIRQ(EXTI1_IRQn);
  HAL_CORTEX_NVIC_SetPendingIRQ(EXTI0_IRQn);

  __enable_irq();

  while (g_irq_count < IRQ_COUNT)
  {
    __NOP();
  }

  HAL_GPIO_WritePin(HAL_GPIOC, HAL_GPIO_PIN_0, HAL_GPIO_PIN_SET);

  if ((g_irq_count == IRQ_COUNT) &&
      (g_irq_order[0] == IRQ_ID_A) &&
      (g_irq_order[1] == IRQ_ID_B) &&
      (g_irq_order[2] == IRQ_ID_C))
  {
    for (uint32_t i = 0U; i < 3U; i++)
    {
      HAL_GPIO_TogglePin(HAL_GPIOC, HAL_GPIO_PIN_0);
      HAL_Delay(250U);
    }
  }

  while (1)
  {
    __WFI();
  }
}
